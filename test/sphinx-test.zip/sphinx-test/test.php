<?php
//zhaigy sphinx web test

header("Content-type: text/html; charset=utf-8");

require ( "sphinxapi.php" );

$host=$_REQUEST["host"];
$port=intval($_REQUEST["port"]);

$q=$_REQUEST["query"];
$index=$_REQUEST["index"];

$match=$_REQUEST["match"];
$rank=$_REQUEST["rank"];
$sort=$_REQUEST["sort"];

$modes=array(	"SPH_MATCH_ALL"=>SPH_MATCH_ALL,
				"SPH_MATCH_ANY"=>SPH_MATCH_ANY,
				"SPH_MATCH_PHRASE"=>SPH_MATCH_PHRASE,
				"SPH_MATCH_BOOLEAN"=>SPH_MATCH_BOOLEAN,
				"SPH_MATCH_EXTENDED"=>SPH_MATCH_EXTENDED,
				"SPH_MATCH_FULLSCAN"=>SPH_MATCH_FULLSCAN,
				"SPH_MATCH_EXTENDED2"=>SPH_MATCH_EXTENDED2	);

$ranks=array(	"SPH_RANK_PROXIMITY_BM25"=>SPH_RANK_PROXIMITY_BM25,
				"SPH_RANK_BM25"=>SPH_RANK_BM25,
				"SPH_RANK_NONE"=>SPH_RANK_NONE,
				"SPH_RANK_WORDCOUNT"=>SPH_RANK_WORDCOUNT,
				"SPH_RANK_PROXIMITY"=>SPH_RANK_PROXIMITY,
				"SPH_RANK_MATCHANY"=>SPH_RANK_MATCHANY,
				"SPH_RANK_FIELDMASK"=>SPH_RANK_FIELDMASK	);
			
$sorts=array(	"SPH_SORT_RELEVANCE"=>SPH_SORT_RELEVANCE,
				"SPH_SORT_ATTR_DESC"=>SPH_SORT_ATTR_DESC,
				"SPH_SORT_ATTR_ASC"=>SPH_SORT_ATTR_ASC,
				"SPH_SORT_TIME_SEGMENTS"=>SPH_SORT_TIME_SEGMENTS,
				"SPH_SORT_EXTENDED"=>SPH_SORT_EXTENDED,
				"SPH_SORT_EXPR"=>SPH_SORT_EXPR	);
				
$match=$modes[$match];
$rank=$ranks[$rank];
$sort=$sorts[$sort];

$filter=$_REQUEST["filter"];
$filtervals=array();

//$groupby

$limit=intval($_REQUEST["limit"]);

//回显
print "回显：\n";
print "host=[$host]\n";
print "port=[$port]\n";

print "index=[$index]\n";
print "q=[$q]\n";
print "filter=[$filter]\n";

print "match=[$match]\n";
print "rank=[$rank]\n";
print "sort=[$sort]\n";

print "limit=[$limit]\n";

print "---------------------------------------\n";

//

$cl = new SphinxClient ();
$cl->SetServer ( $host, $port );

$cl->SetConnectTimeout ( 1 );
//设置，以数组方式返回
//默认方式是hash，它会忽略掉排序
$cl->SetArrayResult ( true );
//$cl->SetWeights ( array ( 100, 1 ) );
//设置匹配模式
$cl->SetMatchMode ( $match );
//设置过滤器，过滤器实际上是在匹配文档列表的基础上，再根据指定的属性的值，逐个的进行判断。
//过滤器，必须要指定一个属性名和至少一个属性值
//if ( count($filtervals) )       $cl->SetFilter ( $filter, $filtervals );
if ( $filter ) {
	$fs=explode(";",$filter);
	foreach($fs as $f){
		$kv=explode(":",$f);
		$vs=explode(",",$kv[1]);
		$intvs=array();
		foreach($vs as $v){
			$intvs[]=intval($v);
		}
		if( count($intvs) ) {
			$cl->SetFilter ( $kv[0], $intvs );
		}
	}
	unset($intvs);
	unset($ks);
	unset($vs);
	unset($fs);
}
//结果集分组
//groupby是属性名，groupsort是排序列表
if ( $groupby )                         $cl->SetGroupBy ( $groupby, SPH_GROUPBY_ATTR, $groupsort );
//设置排序模式
if ( $sort )                          $cl->SetSortMode ( SPH_SORT_EXTENDED, $sort );
//分组中的不同属性值统计，可以看作二级统计
if ( $distinct )                        $cl->SetGroupDistinct ( $distinct );
//要返回的属性和表达式列表
if ( $select )                          $cl->SetSelect ( $select );
//限定结果集的浏览区间
if ( $limit )                           $cl->SetLimits ( 0, $limit, ( $limit>1000 ) ? $limit : 1000 );
//设置评分模式
$cl->SetRankingMode ( $rank );
//查询
$res = $cl->Query ( $q, $index );

// 打印结果
print_r ($res);

//$status = $cl->Status ();
//foreach ( $status as $row )
//    print join (": ",$row)."\n";


return;
?>
